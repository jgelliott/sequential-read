﻿namespace Read
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            this.lblbranch = new System.Windows.Forms.Label();
            this.lblgrade = new System.Windows.Forms.Label();
            this.lbldiploma = new System.Windows.Forms.Label();
            this.lblrecord = new System.Windows.Forms.Label();
            this.lbldrugs = new System.Windows.Forms.Label();
            this.lblweight = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(37, 44);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(159, 116);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(246, 44);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(246, 114);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Branch of Interest";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(33, 184);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Grade Level";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(33, 254);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Has Diploma";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(33, 324);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(173, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Has Criminal Record";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(33, 394);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(204, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "Has History of Drug Use";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(33, 464);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(216, 20);
            this.label7.TabIndex = 7;
            this.label7.Text = "Passes Weight Standards";
            // 
            // lblFname
            // 
            this.lblFname.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblFname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFname.Location = new System.Drawing.Point(415, 47);
            this.lblFname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(97, 20);
            this.lblFname.TabIndex = 8;
            this.lblFname.Click += new System.EventHandler(this.lblFname_Click);
            // 
            // lblbranch
            // 
            this.lblbranch.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblbranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbranch.Location = new System.Drawing.Point(415, 117);
            this.lblbranch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblbranch.Name = "lblbranch";
            this.lblbranch.Size = new System.Drawing.Size(97, 20);
            this.lblbranch.TabIndex = 9;
            this.lblbranch.Click += new System.EventHandler(this.lblbranch_Click);
            // 
            // lblgrade
            // 
            this.lblgrade.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblgrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgrade.Location = new System.Drawing.Point(269, 188);
            this.lblgrade.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblgrade.Name = "lblgrade";
            this.lblgrade.Size = new System.Drawing.Size(97, 20);
            this.lblgrade.TabIndex = 10;
            this.lblgrade.Click += new System.EventHandler(this.lblgrade_Click);
            // 
            // lbldiploma
            // 
            this.lbldiploma.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lbldiploma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiploma.Location = new System.Drawing.Point(269, 257);
            this.lbldiploma.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldiploma.Name = "lbldiploma";
            this.lbldiploma.Size = new System.Drawing.Size(97, 20);
            this.lbldiploma.TabIndex = 11;
            this.lbldiploma.Click += new System.EventHandler(this.lbldiploma_Click);
            // 
            // lblrecord
            // 
            this.lblrecord.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblrecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrecord.Location = new System.Drawing.Point(269, 328);
            this.lblrecord.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblrecord.Name = "lblrecord";
            this.lblrecord.Size = new System.Drawing.Size(97, 20);
            this.lblrecord.TabIndex = 12;
            this.lblrecord.Click += new System.EventHandler(this.lblrecord_Click);
            // 
            // lbldrugs
            // 
            this.lbldrugs.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lbldrugs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldrugs.Location = new System.Drawing.Point(269, 398);
            this.lbldrugs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldrugs.Name = "lbldrugs";
            this.lbldrugs.Size = new System.Drawing.Size(97, 20);
            this.lbldrugs.TabIndex = 13;
            this.lbldrugs.Click += new System.EventHandler(this.lbldrugs_Click);
            // 
            // lblweight
            // 
            this.lblweight.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblweight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblweight.Location = new System.Drawing.Point(269, 464);
            this.lblweight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblweight.Name = "lblweight";
            this.lblweight.Size = new System.Drawing.Size(97, 20);
            this.lblweight.TabIndex = 14;
            this.lblweight.Click += new System.EventHandler(this.lblweight_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(588, 520);
            this.Controls.Add(this.lblweight);
            this.Controls.Add(this.lbldrugs);
            this.Controls.Add(this.lblrecord);
            this.Controls.Add(this.lbldiploma);
            this.Controls.Add(this.lblgrade);
            this.Controls.Add(this.lblbranch);
            this.Controls.Add(this.lblFname);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblFname;
        private System.Windows.Forms.Label lblbranch;
        private System.Windows.Forms.Label lblgrade;
        private System.Windows.Forms.Label lbldiploma;
        private System.Windows.Forms.Label lblrecord;
        private System.Windows.Forms.Label lbldrugs;
        private System.Windows.Forms.Label lblweight;
    }
}

